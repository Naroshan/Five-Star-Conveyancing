// Five Star Conveyancing — API handler integration tests
// Exercises createQuoteHandler and getQuoteHandler end to end against a real
// PostgreSQL database using real Fetch API Request objects — the same
// objects a Next.js route handler receives. Fictional fixture data only.

import { afterAll, beforeEach, describe, expect, it } from 'vitest';
import { sql } from 'kysely';
import { createDb } from '../src/db/client.js';
import { createQuoteHandler } from '../src/api/createQuote.js';
import { getQuoteHandler } from '../src/api/getQuote.js';
import { selectFirmHandler } from '../src/api/selectFirm.js';
import { RateLimiter } from '../src/api/rateLimiter.js';

const connectionString = process.env.DATABASE_URL;

if (connectionString) {
  describe('API handlers (integration, real Postgres)', () => {
    const db = createDb(connectionString);

    afterAll(async () => {
      await db.destroy();
    });

    beforeEach(async () => {
      await sql`truncate table quote_results, quotes, sdlt_ltt_rate_table, disbursement_rules, fee_rules, fee_value_bands, firm_restrictions, firm_transaction_types, firms restart identity cascade`.execute(
        db
      );

      await db
        .insertInto('firms')
        .values([{ firm_id: '11111111-1111-1111-1111-111111111111', legal_entity_name: 'Test Firm A (fixture)', status: 'active', quote_validity_days: 14 }])
        .execute();
      await db
        .insertInto('firm_transaction_types')
        .values([{ firm_id: '11111111-1111-1111-1111-111111111111', transaction_type: 'purchase', accepted: true }])
        .execute();
      await db
        .insertInto('fee_value_bands')
        .values([
          {
            firm_id: '11111111-1111-1111-1111-111111111111',
            transaction_type: 'purchase',
            value_min: 0,
            value_max: null,
            boundary_rule: 'inclusive_upper',
            base_fee: 900,
            effective_date: '2020-01-01',
            approval_status: 'approved',
          },
        ])
        .execute();
      await db
        .insertInto('fee_rules')
        .values([
          {
            firm_id: '11111111-1111-1111-1111-111111111111',
            transaction_type: 'purchase',
            charge_name: 'Legal fee',
            charge_type: 'base_fee',
            trigger_key: null,
            calculation_type: 'fixed',
            vat_treatment: 'standard',
            is_guaranteed: true,
            is_estimated: false,
            effective_date: '2020-01-01',
            approval_status: 'approved',
            display_order: 1,
            client_facing_explanation: 'Base conveyancing fee.',
          },
        ])
        .execute();
      await db
        .insertInto('sdlt_ltt_rate_table')
        .values([
          {
            jurisdiction: 'england',
            band_min: 0,
            band_max: null,
            rate_percentage: 1,
            relief_type: null,
            effective_date: '2020-01-01',
            source_reference: 'TEST FIXTURE — not a real rate',
          },
        ])
        .execute();
    });

    function postRequest(body: unknown, headers: Record<string, string> = {}): Request {
      return new Request('https://example.invalid/api/quotes', {
        method: 'POST',
        headers: { 'content-type': 'application/json', ...headers },
        body: JSON.stringify(body),
      });
    }

    const validBody = {
      transactionType: 'purchase',
      postcode: 'SW1A 1AA',
      jurisdiction: 'england',
      propertyValue: 200_000,
      freeholdOrLeasehold: 'freehold',
      mortgageInvolved: true,
      flags: {},
    };

    it('creates a quote, persists it, and returns line-itemised results with SDLT', async () => {
      const response = await createQuoteHandler(postRequest(validBody), { db });
      expect(response.status).toBe(201);
      const body = await response.json();

      expect(body.quoteReference).toMatch(/^FSC-/);
      expect(body.results).toHaveLength(1);
      expect(body.results[0].eligibilityStatus).toBe('eligible');
      expect(body.results[0].firm.legalEntityName).toBe('Test Firm A (fixture)');
      expect(body.results[0].firm.firmId).toBe('11111111-1111-1111-1111-111111111111');
      expect(body.results[0].legalFeeSubtotal).toBe(900);
      expect(body.results[0].sdltEstimate).toBe(2_000); // 200,000 * 1% test rate
      expect(body.results[0].lineItems.length).toBeGreaterThan(0);
      expect(body.results[0].calculationAudit).toBeUndefined(); // stripped from the public response
    });

    it('rejects an invalid request with 400 and validation details', async () => {
      const response = await createQuoteHandler(postRequest({ ...validBody, propertyValue: -5 }), { db });
      expect(response.status).toBe(400);
      const body = await response.json();
      expect(body.error.message).toBeDefined();
      expect(body.error.details).toBeDefined();
    });

    it('rejects malformed JSON with 400', async () => {
      const request = new Request('https://example.invalid/api/quotes', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: '{not valid json',
      });
      const response = await createQuoteHandler(request, { db });
      expect(response.status).toBe(400);
    });

    it('enforces the rate limiter when one is supplied', async () => {
      const rateLimiter = new RateLimiter({ maxRequests: 2, windowMs: 60_000 });
      const headers = { 'x-forwarded-for': '203.0.113.7' };

      const first = await createQuoteHandler(postRequest(validBody, headers), { db, rateLimiter });
      const second = await createQuoteHandler(postRequest(validBody, headers), { db, rateLimiter });
      const third = await createQuoteHandler(postRequest(validBody, headers), { db, rateLimiter });

      expect(first.status).toBe(201);
      expect(second.status).toBe(201);
      expect(third.status).toBe(429);
    });

    it('retrieves a created quote by reference with full results', async () => {
      const createResponse = await createQuoteHandler(postRequest(validBody), { db });
      const created = await createResponse.json();

      const getResponse = await getQuoteHandler(created.quoteReference, db);
      expect(getResponse.status).toBe(200);
      const body = await getResponse.json();

      expect(body.status).toBe('active');
      expect(body.results[0].totalEstimate).toBe(created.results[0].totalEstimate);
      expect(body.results[0].firm.legalEntityName).toBe(created.results[0].firm.legalEntityName);
      // The fix for the "GET loses line items" gap — confirms the itemised
      // breakdown survives a save/reload round trip, not just a fresh POST.
      expect(body.results[0].lineItems.length).toBe(created.results[0].lineItems.length);
      expect(body.results[0].lineItems[0].chargeName).toBe(created.results[0].lineItems[0].chargeName);
    });

    it('returns 404 for an unknown reference', async () => {
      const response = await getQuoteHandler('FSC-DOES-NOT-EXIST', db);
      expect(response.status).toBe(404);
    });

    it('returns an expired state (not stale figures) for a lapsed quote, and flips status in the database', async () => {
      const createResponse = await createQuoteHandler(postRequest(validBody), { db });
      const created = await createResponse.json();

      // Force it into the past — firm's quote_validity_days was 14, so backdate expiry.
      await sql`update quotes set expiry_at = now() - interval '1 day' where quote_reference = ${created.quoteReference}`.execute(db);

      const getResponse = await getQuoteHandler(created.quoteReference, db);
      const body = await getResponse.json();
      expect(getResponse.status).toBe(200);
      expect(body.status).toBe('expired');
      expect(body.results).toBeUndefined();
      expect(body.message).toContain('expired');

      const row = await db.selectFrom('quotes').select('status').where('quote_reference', '=', created.quoteReference).executeTakeFirstOrThrow();
      expect(row.status).toBe('expired'); // lazy transition persisted
    });

    it('round-trips a sale_and_purchase quote with two leg-tagged base-fee line items', async () => {
      // sale_and_purchase has no scale of its own — the purchase leg reuses
      // the 'purchase'-scoped firm_transaction_types/fee_value_bands/fee_rules
      // already seeded by beforeEach (base_fee 900) for this test firm; only
      // a 'sale'-scoped set needs adding here, with a DIFFERENT base_fee
      // (800) so the summed total can't be a coincidence of shared data.
      await db
        .insertInto('firm_transaction_types')
        .values([{ firm_id: '11111111-1111-1111-1111-111111111111', transaction_type: 'sale', accepted: true }])
        .execute();
      await db
        .insertInto('fee_value_bands')
        .values([
          {
            firm_id: '11111111-1111-1111-1111-111111111111',
            transaction_type: 'sale',
            value_min: 0,
            value_max: null,
            boundary_rule: 'inclusive_upper',
            base_fee: 800,
            effective_date: '2020-01-01',
            approval_status: 'approved',
          },
        ])
        .execute();
      await db
        .insertInto('fee_rules')
        .values([
          {
            firm_id: '11111111-1111-1111-1111-111111111111',
            transaction_type: 'sale',
            charge_name: 'Legal fee',
            charge_type: 'base_fee',
            trigger_key: null,
            calculation_type: 'fixed',
            vat_treatment: 'standard',
            is_guaranteed: true,
            is_estimated: false,
            effective_date: '2020-01-01',
            approval_status: 'approved',
            display_order: 1,
            client_facing_explanation: 'Base conveyancing fee.',
          },
        ])
        .execute();

      const saleAndPurchaseBody = {
        transactionType: 'sale_and_purchase',
        postcode: 'SW1A 1AA',
        jurisdiction: 'england',
        salePropertyValue: 200_000,
        purchasePropertyValue: 300_000,
        freeholdOrLeasehold: 'freehold',
        mortgageInvolved: true,
        flags: {},
      };

      const createResponse = await createQuoteHandler(postRequest(saleAndPurchaseBody), { db });
      expect(createResponse.status).toBe(201);
      const created = await createResponse.json();
      // Sale leg (800, from the 'sale'-scoped band just seeded) + purchase
      // leg (900, from beforeEach's 'purchase'-scoped band) = 1,700 — proves
      // each leg reads its OWN scope, not a shared/duplicated one.
      expect(created.results[0].legalFeeSubtotal).toBe(1_700);
      // SDLT reflects the purchase leg only (300,000 * 1% test rate = 3,000),
      // never the sale leg (which would give 2,000).
      expect(created.results[0].sdltEstimate).toBe(3_000);

      const getResponse = await getQuoteHandler(created.quoteReference, db);
      const fetched = await getResponse.json();
      const legalFeeLines = fetched.results[0].lineItems.filter((l: { category: string }) => l.category === 'legal_fee');
      expect(legalFeeLines).toHaveLength(2);
      expect(legalFeeLines.map((l: { leg?: string }) => l.leg).sort()).toEqual(['purchase', 'sale']);
    });

    function selectRequest(body: unknown): Request {
      return new Request('https://example.invalid/api/quotes/x/select', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(body),
      });
    }

    const validContact = { name: 'Jane Doe', email: 'jane@example.com', phone: '07700 900000' };

    describe('selectFirmHandler ("Select this firm" lead handoff)', () => {
      it('records the selection, flips the quote to converted, and persists the contact details', async () => {
        const created = await (await createQuoteHandler(postRequest(validBody), { db })).json();
        const firmId = created.results[0].firm.firmId;

        const response = await selectFirmHandler(created.quoteReference, selectRequest({ firmId, contact: validContact }), db);
        expect(response.status).toBe(200);
        const body = await response.json();
        expect(body).toEqual({ quoteReference: created.quoteReference, selectedFirmId: firmId, status: 'converted' });

        const row = await db
          .selectFrom('quotes')
          .select(['status', 'selected_firm_id', 'client_name', 'client_email', 'client_phone'])
          .where('quote_reference', '=', created.quoteReference)
          .executeTakeFirstOrThrow();
        expect(row.status).toBe('converted');
        expect(row.selected_firm_id).toBe(firmId);
        expect(row.client_name).toBe(validContact.name);
        expect(row.client_email).toBe(validContact.email);
        expect(row.client_phone).toBe(validContact.phone);
      });

      it('returns 404 for an unknown reference', async () => {
        const response = await selectFirmHandler(
          'FSC-DOES-NOT-EXIST',
          selectRequest({ firmId: '11111111-1111-1111-1111-111111111111', contact: validContact }),
          db
        );
        expect(response.status).toBe(404);
      });

      it('rejects a firmId that is not an eligible result on this quote', async () => {
        const created = await (await createQuoteHandler(postRequest(validBody), { db })).json();
        const response = await selectFirmHandler(
          created.quoteReference,
          selectRequest({ firmId: '99999999-9999-9999-9999-999999999999', contact: validContact }),
          db
        );
        expect(response.status).toBe(400);
      });

      it('rejects a missing or non-string firmId', async () => {
        const created = await (await createQuoteHandler(postRequest(validBody), { db })).json();
        expect((await selectFirmHandler(created.quoteReference, selectRequest({ contact: validContact }), db)).status).toBe(400);
        expect((await selectFirmHandler(created.quoteReference, selectRequest({ firmId: 42, contact: validContact }), db)).status).toBe(400);
      });

      it('rejects a missing or invalid contact', async () => {
        const created = await (await createQuoteHandler(postRequest(validBody), { db })).json();
        const firmId = created.results[0].firm.firmId;
        expect((await selectFirmHandler(created.quoteReference, selectRequest({ firmId }), db)).status).toBe(400);
        expect(
          (await selectFirmHandler(created.quoteReference, selectRequest({ firmId, contact: { name: '', email: 'not-an-email', phone: '' } }), db))
            .status
        ).toBe(400);
      });

      it('rejects malformed JSON with 400', async () => {
        const request = new Request('https://example.invalid/api/quotes/x/select', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: '{not valid json',
        });
        const response = await selectFirmHandler('FSC-ANYTHING', request, db);
        expect(response.status).toBe(400);
      });

      it('refuses to select a firm on an already-converted quote', async () => {
        const created = await (await createQuoteHandler(postRequest(validBody), { db })).json();
        const firmId = created.results[0].firm.firmId;

        const first = await selectFirmHandler(created.quoteReference, selectRequest({ firmId, contact: validContact }), db);
        expect(first.status).toBe(200);

        const second = await selectFirmHandler(created.quoteReference, selectRequest({ firmId, contact: validContact }), db);
        expect(second.status).toBe(409);
      });

      it('refuses to select a firm on an expired quote', async () => {
        const created = await (await createQuoteHandler(postRequest(validBody), { db })).json();
        const firmId = created.results[0].firm.firmId;
        await sql`update quotes set expiry_at = now() - interval '1 day' where quote_reference = ${created.quoteReference}`.execute(db);

        const response = await selectFirmHandler(created.quoteReference, selectRequest({ firmId, contact: validContact }), db);
        expect(response.status).toBe(409);
      });
    });

    describe('createQuoteHandler contact details', () => {
      it('persists contact details when provided at quote creation', async () => {
        const created = await (
          await createQuoteHandler(postRequest({ ...validBody, contact: validContact }), { db })
        ).json();
        const row = await db
          .selectFrom('quotes')
          .select(['client_name', 'client_email', 'client_phone'])
          .where('quote_reference', '=', created.quoteReference)
          .executeTakeFirstOrThrow();
        expect(row.client_name).toBe(validContact.name);
        expect(row.client_email).toBe(validContact.email);
        expect(row.client_phone).toBe(validContact.phone);
      });

      it('allows quote creation without contact details (homepage widget flow)', async () => {
        const response = await createQuoteHandler(postRequest(validBody), { db });
        expect(response.status).toBe(201);
      });

      it('rejects invalid contact details at quote creation', async () => {
        const response = await createQuoteHandler(
          postRequest({ ...validBody, contact: { name: '', email: 'not-an-email', phone: '' } }),
          { db }
        );
        expect(response.status).toBe(400);
      });
    });
  });
} else {
  describe.skip('API handlers (integration, real Postgres) — set DATABASE_URL to run', () => {
    it('skipped: no DATABASE_URL set', () => {});
  });
}
